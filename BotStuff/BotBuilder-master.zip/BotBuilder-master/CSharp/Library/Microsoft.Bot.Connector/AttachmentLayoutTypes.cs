﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsoft.Bot.Connector
{
    public class AttachmentLayoutTypes
    {
        public const string List = "list";
        public const string Carousel = "carousel";
    }
}