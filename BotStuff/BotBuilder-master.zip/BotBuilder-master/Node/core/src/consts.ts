﻿// 
// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license.
// 
// Microsoft Bot Framework: http://botframework.com
// 
// Bot Builder SDK Github:
// https://github.com/Microsoft/BotBuilder
// 
// Copyright (c) Microsoft Corporation
// All rights reserved.
// 
// MIT License:
// Permission is hereby granted, free of charge, to any person obtaining
// a copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to
// permit persons to whom the Software is furnished to do so, subject to
// the following conditions:
// 
// The above copyright notice and this permission notice shall be
// included in all copies or substantial portions of the Software.
// 
// THE SOFTWARE IS PROVIDED ""AS IS"", WITHOUT WARRANTY OF ANY KIND,
// EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
// NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
// LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
// OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
// WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//

export var agent = 'botbuilder';
export var messageType = 'message';
export var defaultConnector = '*';
export var emulatorChannel = 'emulator';

export var Errors = {
    EMSGSIZE: 'EMSGSIZE',
    EBADMSG: 'EBADMSG'
};

export var Library =  {
    system: 'BotBuilder',
    default: '*'
};

export var Data = {
    SessionState: 'BotBuilder.Data.SessionState',
    SessionId: 'BotBuilder.Data.SessionId',
    Handler: 'BotBuilder.Data.Handler',
    Group: 'BotBuilder.Data.Group',
    Intent: 'BotBuilder.Data.Intent',
    WaterfallStep: 'BotBuilder.Data.WaterfallStep',
    Form: 'BotBuilder.Data.Form',
    Field: 'BotBuilder.Data.Field',
    FirstRunVersion: 'BotBuilder.Data.FirstRunVersion',
    PreferredLocale: 'BotBuilder.Data.PreferredLocale'
};

export var DialogId = {
    Prompts: 'BotBuilder:Prompts',
    FirstRun: 'BotBuilder:FirstRun',
    Field: 'BotBuilder:Field'
};

export var Id = {
    DefaultGroup: 'BotBuilder.Id.DefaultGroup'
};

export var Intents = {
    Default: 'BotBuilder.Intents.Default'
};